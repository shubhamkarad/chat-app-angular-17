import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, RouterOutlet, Routes } from '@angular/router';
import { MatIconModule, MatIcon } from '@angular/material/icon';
import { AppComponent } from '../app.component';
import { PageComponent } from '../page/page.component';
import { MainChatComponent } from '../ui/main-chat/main-chat.component';
import { CommonModule } from '@angular/common';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { UploadFileComponent } from '../ui/upload-file/upload-file.component';
import { SharedDataService } from '../service.service';
import { PdfViewerComponent } from '../ui/pdf-viewer/pdf-viewer.component';
const routes: Routes = [
  { path: '', component: PageComponent },
  { path: 'chat', component: MainChatComponent },
];
@NgModule({
  declarations: [
    AppComponent,
    PageComponent,
    MainChatComponent,
    UploadFileComponent,
    PdfViewerComponent,
  ],
  imports: [
    // BrowserModule,
    // RouterModule.forRoot(routes),
    MatIconModule,
    MatIcon,
    CommonModule,
    RouterOutlet,
    NgxExtendedPdfViewerModule,
  ],
  providers: [SharedDataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
