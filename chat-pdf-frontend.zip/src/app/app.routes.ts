import { Routes } from '@angular/router';
import { MainChatComponent } from './ui/main-chat/main-chat.component';
import { PageComponent } from './page/page.component';
import { ChatPageComponent } from './chat/chat-page/chat-page.component';

export const routes: Routes = [
  { path: '', component: PageComponent },
  { path: 'chat', component: ChatPageComponent },
];
