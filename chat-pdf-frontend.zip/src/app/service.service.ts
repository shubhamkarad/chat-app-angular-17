import { Injectable, signal } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SharedDataService {
  sharedDataSubject = new BehaviorSubject<any>(null);
  sharedData$ = this.sharedDataSubject.asObservable();
  // sharedData = signal<any>('');
  sendData(data: any) {
    console.log(data, 'Data');
    this.sharedDataSubject.next(data);
  }
}
